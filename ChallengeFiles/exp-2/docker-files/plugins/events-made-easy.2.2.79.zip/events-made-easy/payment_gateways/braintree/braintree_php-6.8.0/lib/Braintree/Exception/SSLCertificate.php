<?php

namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when the SSL certificate fails verification.
 */
class SSLCertificate extends Exception
{
}
