Source: https://github.com/noppa/text-security
