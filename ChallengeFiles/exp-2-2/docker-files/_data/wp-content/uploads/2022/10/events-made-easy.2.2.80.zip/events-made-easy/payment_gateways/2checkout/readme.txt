See https://github.com/2Checkout/2checkout-php/wiki
