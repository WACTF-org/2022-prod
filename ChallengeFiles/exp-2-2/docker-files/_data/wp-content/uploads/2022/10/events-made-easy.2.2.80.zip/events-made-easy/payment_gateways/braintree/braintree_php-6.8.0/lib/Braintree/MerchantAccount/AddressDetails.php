<?php

namespace Braintree\MerchantAccount;

use Braintree\Instance;

/**
 * Creates an instance of AddressDetails as returned from a merchant account
 */
class AddressDetails extends Instance
{
    protected $_attributes = [];
}
