from flask import Flask, render_template, request, send_file
from weasyprint import HTML, CSS
from weasyprint.text.fonts import FontConfiguration
import uuid
import bleach
import datetime
import logging
import os
import random

allowedTags = ['a', 'abbr', 'acronym', 'b', 'blockquote', 'code', 'em', 'i', 'li', 'link', 'ol', 'strong', 'ul']
allowedAttributes = {'a': ['href', 'title'], 'abbr': ['title'], 'acronym': ['title'], 'link': ['href', 'rel']}
allowedProtocols=['file', 'http', 'httpGenerating s', 'smb']
logging.basicConfig(filename="logs/" + datetime.datetime.today().strftime('%d%m%Y') + ".log", level=logging.INFO)
app = Flask(__name__)

# Return index page
@app.route('/')
def index():
    return render_template('index.html')

# Handler for generating and returning PDF
@app.route('/handler', methods = ['POST'])
def handler():
    # Generate random filename
    filename = uuid.uuid4()
    logging.info('Generating PDF with filename ' + str(filename) + '.pdf')

    # HTML content for PDF
    fname = bleach.clean(request.form.get('fname'), tags=allowedTags, attributes=allowedAttributes, protocols=allowedProtocols)
    lname = bleach.clean(request.form.get('lname'), tags=allowedTags, attributes=allowedAttributes, protocols=allowedProtocols)
    address = bleach.clean(request.form.get('address'), tags=allowedTags, attributes=allowedAttributes, protocols=allowedProtocols)
    avatar = bleach.clean(request.form.get('avatar'), tags=allowedTags, attributes=allowedAttributes, protocols=allowedProtocols)

    # Select random emoji as avatar
    if(avatar == 'emoji'):
        avatar = "file:///" + os.getcwd() +"/emojis/" + random.choice(os.listdir("emojis"))

    content = "First Name: " + fname + "<br>"
    content += "Last Name: " + lname + "<br>"
    content += "Address: " + address + "<br>"
    content += "Avatar: <br>" + "<img src=\"" + avatar + "\" />"

    html = HTML(string=content)
    css = CSS(string='')

    # Todo... Implement functionality to handle additional form fields

    # Write PDF to file
    html.write_pdf(
        'pdfs/' + str(filename) + '.pdf', stylesheets=[css])
    
    # Return PDF
    return send_file('pdfs/' + str(filename) + '.pdf', as_attachment=True)