window.config = {
  ApiEndpoint: '/api',
  LoginEndpoint: '/login.php',
  LogoutEndpoint: '/logout.php',
  InfoEndpoint: '/info.php',
};
